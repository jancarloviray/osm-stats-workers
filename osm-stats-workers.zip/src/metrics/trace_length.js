// var measureWayLength = require('../common/measure_way_length');

// Hypothetically takes GPS traces, returns total length in KM
module.exports = function (gpsTraces) {
  return 0;
  // return measureWayLength(gpsTraces);
};
